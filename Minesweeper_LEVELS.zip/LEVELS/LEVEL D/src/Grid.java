import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.InputMismatchException;
import java.util.Random;

public class Grid extends JFrame{

    /**
     * variables of Level B
     */

    private JPanel panel;
    private JLabel label;
    private JOptionPane jOptionPane;
    private Player p1, p2; // added in level C

    PlayerHelper ph = new PlayerHelper();


    protected Dimension screenSize;

    final int image_size = 50;// added in Level B

    static int x_in_class;
    static int y_in_class;
    static int count_for_click;

    protected boolean stopGame;

    protected int first = 0;
    protected int numberofBombs;
    protected int numOpen ;
    protected int columns ;// added in Level B | NUMBER OF COLUMNS
    protected int rows;// added in Level B |NUMBER OF ROWS
    protected int height; // added in level D When the size change of window is considered
    protected int width;// added in level D When the size change of window is considered

    HashMap<Integer, Integer> array_of_opened_squares;
    ArrayList<HashMap<Integer, Integer> > arrayList_of_opened_squares; // for storing the opened squares
    protected Random rand = new Random();

    private Square[][] m; // matrix for squares

    public void setSizeof_grid() { // from A level

        screenSize  = Toolkit.getDefaultToolkit().getScreenSize();

        // screen size is used to determine the maximum number of squares on the display
        height = (int)screenSize.getHeight();
        width =  (int)screenSize.getWidth();


        while(true){
        try {
            // check for incorrect answers

            String input_col = jOptionPane.showInputDialog("Please, enter your columns size"); // added in level D
            String input_row = jOptionPane.showInputDialog("Please, enter your row size");// added in level D

            int input_col_int =Integer.parseInt(input_col);

            int input_row_int =Integer.parseInt(input_row);

            if(jOptionPane.CLOSED_OPTION!=-1) break;



            if(input_row_int*image_size >= height){
                input_row_int = (height-100)/image_size; // maximum size of the height
            }

            if(input_col_int*image_size >= width){
                input_col_int= width/image_size;
            }


            setColumns(input_row_int); // reverse ordering because it is how the matrix works
            setRows(input_col_int);

            break;

        } catch (InputMismatchException e) {
            System.out.println(" Input is not correct");
            jOptionPane.showMessageDialog(null, "Number format is not correct. Entered number is wrong. ");
        } catch (NumberFormatException n) {
            System.out.println("Number format is not correct. Entered number is wrong. ");
            jOptionPane.showMessageDialog(null, "Number format is not correct. Entered number is wrong. ");
        }
    }

        m = new Square[rows][columns];

        if( rows <=15 && rows >=10 && columns <=15 && columns >=10){
            int max, min;
            min = Math.min(rows,columns);
            max = Math.max(rows,columns);
            numberofBombs = 10 + rand.nextInt((max - min) + 1) + min;

            }else if(rows<=18 && rows>=16 && columns <=18 && columns >=16){
            int max, min;
            min = Math.min(rows,columns);
            max = Math.max(rows,columns);
            numberofBombs = 25 + rand.nextInt((max - min) + 1) + min;


        }else if (rows>=19 && columns>=19 && columns<=30){
            int max, min;
            min = Math.min(rows,columns);
            max = Math.max(rows,columns);
            numberofBombs = 45 + rand.nextInt((max - min) + 1) + min;
        }else if(rows>=19 && columns>=31){
            int max, min;
            min = Math.min(rows,columns);
            max = Math.max(rows,columns);
            numberofBombs = 75 + rand.nextInt((max - min) + 1) + min;
        }

        else{
            int max,min;
            min = Math.min(rows,columns);
            max = Math.max(rows,columns);
            numberofBombs = min + rand.nextInt(max) + 1;
        }


    }
    public void setPlayers() {

        while(true){
            try {
                String name1 = jOptionPane.showInputDialog("Please, enter name of 1st player"); // added in level C
                String name2 = jOptionPane.showInputDialog("Please, enter name of 2nd player");// added in level C

                String name1_lower = name1.toLowerCase();
                String name2_lower  = name2.toLowerCase();

                if(name1_lower.equals(name2_lower)){
                    name1 = name1 + "(1)";
                    name2 = name2 + "(2)";
                }

                p1 = new Player(name1);
                p2 = new Player(name2);
                break;
            } catch (InputMismatchException e) {
                System.out.println(" Input is not correct");
                jOptionPane.showMessageDialog(null, "Name format is not correct.");
            }
        }
    }

    public void startGame(){
        startGraphical();
    }


    public void startGraphical(){

        setImages(); // images are downloaded to the game

        initializePanel();
        initLabel(p1.getName());
        initalizeFrame();

        // initialization and assigning of values
        count_for_click =0;
        x_in_class = -1;
        y_in_class = -1;
        stopGame = false;
        numOpen= 0;
        array_of_opened_squares = new HashMap< Integer,Integer>();
        arrayList_of_opened_squares = new ArrayList<>();



        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < columns; j++) {
                m[i][j] = new Square();
            }
        }

        int i = 0;

        while (i < numberofBombs) {

            int rows = rand.nextInt(this.rows);// x - rows
            // for each x and y random number is generated

            int columns = rand.nextInt(this.columns); // y - columns


            if (!m[rows][columns].isMine()) { // checking whether the mine is present or not

                m[rows][columns].setMine(true); // mine is placed at matrix m[x][y]

                m[rows][columns].setVal(-1); // value of bomb/mine now is -1

                // val here stands for a number of bombs around the coordinates of [x][y]

                // at [x][y] -1 is set as there is no number but bomb is present

                try {
                    if (!m[rows - 1][columns - 1].isMine()) {
                        m[rows - 1][columns - 1].setVal(m[rows - 1][columns - 1].getVal() + 1);
                    }

                } catch (Exception ex) {

                }

                try {
                    if (!m[rows - 1][columns].isMine()) {
                        m[rows - 1][columns].setVal(m[rows - 1][columns].getVal() + 1);
                    }
                } catch (Exception ex) {

                }

                try {
                    if (!m[rows - 1][columns + 1].isMine()) {
                        m[rows - 1][columns + 1].setVal(m[rows - 1][columns + 1].getVal() + 1);
                    }
                } catch (Exception ex) {

                }

                try {
                    if (!m[rows][columns - 1].isMine()) {
                        m[rows][columns - 1].setVal(m[rows][columns - 1].getVal() + 1);
                    }
                } catch (Exception ex) {

                }

                try {
                    if (!m[rows][columns + 1].isMine()) {
                        m[rows][columns + 1].setVal(m[rows][columns + 1].getVal() + 1);
                    }
                } catch (Exception ex) {

                }

                try {
                    if (!m[rows + 1][columns - 1].isMine()) {
                        m[rows + 1][columns - 1].setVal(m[rows + 1][columns - 1].getVal() + 1);
                    }
                } catch (Exception ex) {

                }

                try {
                    if (!m[rows + 1][columns].isMine()) {
                        m[rows + 1][columns].setVal(m[rows + 1][columns].getVal() + 1);
                    }
                } catch (Exception ex) {

                }
                try {
                    if (!m[rows + 1][columns + 1].isMine()) {
                        m[rows + 1][columns + 1].setVal(m[rows + 1][columns + 1].getVal() + 1);
                    }
                } catch (Exception ex) {

                }

                i++;
            }
        }
    }



    public void openGraphicalSquare(int x, int y) {

        if (!m[x][y].isOpen())
        {
            m[x][y].setOpen(true);
            HashMap<Integer, Integer> array_of_opened_squares = new HashMap< Integer,Integer>();

            // everytime when the matrix is opened,the opened values are stored in new empty hashmap
            // then the hashmap is added into the array

            array_of_opened_squares.put(x,y); //here are the coordinates of newly opened squares. Then they are added into the array

            arrayList_of_opened_squares.add(array_of_opened_squares);

            if(!m[x][y].isMine()) {
                numOpen++;
            }

            if(ph.getTurn() == 0) // LEVEL C
                p1.add(1); // LEVEL C
            else
                p2.add(1);// LEVEL C


            // recursively calling itself to open the squares
            if (m[x][y].getVal() == 0) {
                try {
                    openGraphicalSquare(x - 1, y - 1);
                } catch (Exception ex) {

                }
                try {
                    openGraphicalSquare(x - 1, y);
                } catch (Exception ex) {

                }
                try {
                    openGraphicalSquare(x - 1, y + 1);
                } catch (Exception ex) {

                }
                try {
                    openGraphicalSquare(x, y - 1);
                } catch (Exception ex) {

                }
                try {
                    openGraphicalSquare(x, y + 1);
                } catch (Exception ex) {

                }
                try {
                    openGraphicalSquare(x + 1, y - 1);
                } catch (Exception ex) {

                }
                try {
                    openGraphicalSquare(x + 1, y);
                } catch (Exception ex) {

                }
                try {
                    openGraphicalSquare(x + 1, y + 1);
                } catch (Exception ex) {

                }
            }

        }
    }


// HERE will be pictures

    private void setImages()  //images are inserted
    {

        for(Position pictures: Position.values())
        {
            pictures.pictures = getImage(pictures.name());

        }

    }


    private Image getImage(String name_of_Image) { // images are loaded from resources directory

        String filename = name_of_Image.toLowerCase() + ".png";

        return new ImageIcon(getClass().getResource(filename)).getImage();

    }




/** after pictures are downloaded

panel is initialized

 */



public void initializePanel() {

    panel = new JPanel() {
        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);



            if(stopGame == false) {
                // this loop initializes the grid with pictures.
                // CLOSED png files are always generated on the grid.

                for (int i = 0; i < rows; i++) {
                    for (int j = 0; j < columns; j++) {
                        g.drawImage(Position.ClOSED.pictures, i * image_size, j * image_size, this);

                    }
                }



                for (int i = 0; i < rows; i++) {
                    for (int j = 0; j < columns; j++) {

                        for (int k = 0; k < arrayList_of_opened_squares.size(); k++) {

                            if(m[i][j].isFlag()){
                                g.drawImage(Position.FLAGED.pictures, i * image_size, j * image_size, this);
                                }

                            if (!m[i][j].isFlag() && arrayList_of_opened_squares.get(k).containsKey(i) && arrayList_of_opened_squares.get(k).containsValue(j)) {

                                g.drawImage(AssigningSquaresWithPictures().get(m[i][j]), i * image_size, j * image_size, this);

                                if (m[x_in_class][y_in_class].isMine()) {

                                    for(int q =0; q < rows ; q++){

                                        for(int h = 0;h<columns; h++){

                                            if ( m[q][h].isFlag() && !m[q][h].isMine()) {

                                                g.drawImage(Position.NOBOMB.pictures, q * image_size, h * image_size, this);
                                            }

                                            if (m[q][h].isMine()) {
                                                g.drawImage(Position.BOMBED.pictures, q * image_size, h * image_size, this);
                                            }
                                        }
                                    }
                                    stopGame(true); // game is stopped now. restart if needed

                                }
                            }
                        }
                    }
                }
            }
        }
    };


    panel.addMouseListener(new

        MouseAdapter() {

            @Override
            public void mousePressed (MouseEvent e){

                int x;
                int y;
                x = e.getX() / image_size;
                y = e.getY() / image_size;

                if (e.getButton() == MouseEvent.BUTTON1 )// left button of mouse
                {


                    if(count_for_click == 0)
                    {
                        startGraphical();

                        count_for_click++;
                    }


                    if(!m[x][y].isFlag()){

                        setCoordinatesofX(x);

                        setCoordinatesofY(y);

                        openGraphicalSquare(x, y);

                        // BELOW ARE ADDED IN LEVEL C
                        ph.changeT();


                        if(ph.getTurn() == 0){
                            initLabel(p1.getName());

                        }
                        else{
                            initLabel(p2.getName());
                        }



                    }


                }


                if(stopGame == true && e.getButton()== MouseEvent.BUTTON3){
                    startGraphical();
                } // if right button and game is lost then restart game


                if(e.getButton()== MouseEvent.BUTTON3) {


                    if (!m[x][y].isFlag() && !m[x][y].isOpen()) {
                        m[x][y].setFlag(true); // flag is set with right button of mouse. BONUS
                    } else{
                        m[x][y].setFlag(false);
                    }
                }

                panel.repaint(); // after the g panel is painted check whether the player won or no

                if(stopGame == true){

                    if(ph.getTurn()==0)
                        p1.add(-1);
                    else
                        p2.add(-1);
                    if (p1.getScore() > p2.getScore())
                        jOptionPane.showMessageDialog(null, "Oops. You Lost. " + p1.getName() + " has more points. Mine Sweeper did not took the advantage of one chance\n"
                                + p1.getName() +": "+ p1.getScore() + "\n"+ p2.getName()+ ": " + p2.getScore());
                    else if (p1.getScore() < p2.getScore())
                        jOptionPane.showMessageDialog(null, "Oops. You Lost. " + p2.getName() + " has more points. Mine Sweeper did not took the advantage of one chance\n"
                                + p1.getName() + ": " + p1.getScore() + "\n"+ p2.getName()+ ": "+ p2.getScore());
                    else if (p1.getScore() == p2.getScore())
                        jOptionPane.showMessageDialog(null, "Oops. You Lost. You both have same points. Mine Sweeper did not took the advantage of one chance\n"
                                + p1.getName()  + ": " + p1.getScore() + "\n" + p2.getName() +": " + p2.getScore());
                    jOptionPane.showMessageDialog(null, "Press the right button of mouse to restart the game");
                    p1.clear();
                    p2.clear();

                }


                if(stopGame != true && numOpen==(columns*rows-numberofBombs)){


                    // BELOW ARE ADDED IN LEVEL C
                    if(p1.getScore() > p2.getScore())
                        jOptionPane.showMessageDialog(null, "Mine Sweeper took the advantage of one chance. " + p1.getName() + " Win! Congrats!\n"
                                + p1.getName() + ": " + p1.getScore() + "\n"+p2.getName()+": " + p2.getScore());
                    else if(p1.getScore() < p2.getScore())
                        jOptionPane.showMessageDialog(null, "Mine Sweeper took the advantage of one chance. " + p2.getName() + " Win! Congrats!\n"
                                + p1.getName()+": " + p1.getScore() + "\n"+p2.getName()+": " + p2.getScore());
                    if(p1.getScore() == p2.getScore())
                        jOptionPane.showMessageDialog(null, "Mine Sweeper took the advantage of one chance. It is a draw! Congrats!\n"
                                + p1.getName()+": " + p1.getScore() + "\n"+p2.getName()+": " + p2.getScore());
                    p1.clear();
                    p2.clear();

                    startGraphical();

                }


            }
        });





    panel.setPreferredSize(new

        Dimension(rows *image_size, columns *image_size));

        add(panel);

    }


    // after panel is initialized the Frame should be initialized
private void initalizeFrame()
{
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE); // when X is pressed the program terminates
        setTitle("Minesweeper Is Wrong Only Once");
        setResizable(false); // the size of window does not change
        setVisible(true); // window is visible
        setIconImage(getImage("icon")); // sets the icon image for the program
        pack(); //function for calling the size
        setLocationRelativeTo(null); // the program window is located at center
    }

    private void initLabel(String name){

        if(first == 0) {
            label = new JLabel(name + "'s turn");
            add(label, BorderLayout.SOUTH);
            first++;
            return;
        }
        label.setText(name + "'s turn");

    }


    public int setCoordinatesofX(int x){
        x_in_class = x;
        return x_in_class;
    }


    public int setCoordinatesofY(int y){
        y_in_class = y;

        return y_in_class;
    }

    public HashMap<Square,Image> AssigningSquaresWithPictures(){
        HashMap<Square, Image> array_of_things = new HashMap<Square,Image>();
        for(int i =0; i< rows; i++){
            for(int j = 0; j< columns; j++){

                // here nums are assigned with pictures

                switch (m[i][j].getVal())
                {
                    case 0:
                        array_of_things.put(m[i][j], Position.ZERO.pictures);
                        break;
                    case 1:
                        array_of_things.put(m[i][j], Position.NUM1.pictures);
                        break;
                    case 2:
                        array_of_things.put(m[i][j], Position.NUM2.pictures);
                        break;

                    case 3:
                        array_of_things.put(m[i][j], Position.NUM3.pictures);
                        break;
                    case 4:
                        array_of_things.put(m[i][j], Position.NUM4.pictures);
                        break;
                    case 5:
                        array_of_things.put(m[i][j], Position.NUM5.pictures);
                        break;
                    case 6:
                        array_of_things.put(m[i][j], Position.NUM6.pictures);
                        break;
                    case 7:
                        array_of_things.put(m[i][j], Position.NUM7.pictures);
                        break;
                    case 8:
                        array_of_things.put(m[i][j], Position.NUM8.pictures);
                        break;
                }
            }
        }
    return array_of_things;
    }

    public boolean stopGame(boolean b){
        stopGame = b;
        return stopGame;
    }
    public void setColumns(int c){
        columns = c;
    }
    public void setRows(int r ){

        rows = r;
    }


}




