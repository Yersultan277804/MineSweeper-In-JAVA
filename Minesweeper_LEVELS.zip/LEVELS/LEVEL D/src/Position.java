import java.awt.*;


enum Position{

    ZERO, // from zero to 8
    NUM1,
    NUM2,
    NUM3,
    NUM4,
    NUM5,
    NUM6,
    NUM7,
    NUM8,
    FLAGED,
    NOBOMB,
    ClOSED,
    BOMBED;
    public Image pictures;

}