import java.util.InputMismatchException;
import java.util.Random;
import java.util.Scanner;


public class Main {

    int length = 9;
    int numberofBombs = 10;
    int moves = length * length - numberofBombs;

    public boolean isActive(int rows, int columns){
        return (rows >= 0) && (rows < 9) &&
                (columns >= 0) && (columns < 9);
    }

    public boolean isMine (int rows, int columns, char m[][]){
        if (m[rows][columns] == '*')
            return true;
        else
            return false;
    }

    public void printGrid (char gridMatrix[][]) {
        int i, j;
        for (i=0; i<9; i++) {
            for (j=0; j<9; j++) {
                System.out.print(gridMatrix[i][j] + " ");

            }
            System.out.println();
        }
    }

    int countNearMines(int rows, int columns, int mines[][], char matrix[][]) {

        int i;
        int count = 0;

        if (isActive (rows-1, columns) == true)
        {
            if (isMine (rows-1, columns, matrix) == true)
                count++;
        }
        if (isActive (rows+1, columns) == true)
        {
            if (isMine (rows+1, columns, matrix) == true)
                count++;
        }

        if (isActive (rows, columns+1) == true)
        {
            if (isMine (rows, columns+1, matrix) == true)
                count++;
        }

        if (isActive (rows, columns-1) == true)
        {
            if (isMine (rows, columns-1, matrix) == true)
                count++;
        }
        if (isActive (rows-1, columns+1) == true)
        {
            if (isMine (rows-1, columns+1, matrix) == true)
                count++;
        }

        if (isActive (rows-1, columns-1) == true)
        {
            if (isMine (rows-1, columns-1, matrix) == true)
                count++;
        }
        if (isActive (rows+1, columns+1) == true)
        {
            if (isMine (rows+1, columns+1, matrix) == true)
                count++;
        }

        if (isActive (rows+1, columns-1) == true)
        {
            if (isMine (rows+1, columns-1, matrix) == true)
                count++;
        }

        return (count);
    }


    public boolean gameStart(char gridMatrix[][], char matrix[][], int mines[][], int rows, int columns)
    {

        if (gridMatrix[rows][columns] != '-')
            return (false);

        int i, j;

        if (matrix[rows][columns] == '*')
        {
            gridMatrix[rows][columns]='*';

            for (i=0; i<numberofBombs; i++)
                gridMatrix[mines[i][0]][mines[i][1]]='*';

            printGrid (gridMatrix);
            return (true) ;
        }

        else
        {
            int count = countNearMines(rows, columns, mines, matrix);
            moves--;

            gridMatrix[rows][columns] = (char) (count + '0');

            if (count == 0)
            {

                if (isActive (rows-1, columns) == true)
                {
                    if (isMine (rows-1, columns, matrix) == false)
                        gameStart(gridMatrix, matrix, mines, rows-1, columns);
                }




                if (isActive (rows+1, columns) == true)
                {
                    if (isMine (rows+1, columns, matrix) == false)
                        gameStart(gridMatrix, matrix, mines, rows+1, columns);
                }

                if (isActive (rows, columns+1) == true)
                {
                    if (isMine (rows, columns+1, matrix) == false)
                        gameStart(gridMatrix, matrix, mines, rows, columns+1);
                }
           if (isActive (rows, columns-1) == true)
                {
                    if (isMine (rows, columns-1, matrix) == false)
                        gameStart(gridMatrix, matrix, mines, rows, columns-1);
                }


                if (isActive (rows-1, columns+1) == true)
                {
                    if (isMine (rows-1, columns+1, matrix) == false)
                        gameStart(gridMatrix, matrix, mines, rows-1, columns+1);
                }


                if (isActive (rows-1, columns-1) == true)
                {
                    if (isMine (rows-1, columns-1, matrix) == false)
                        gameStart(gridMatrix, matrix, mines, rows-1, columns-1);
                }


                if (isActive (rows+1, columns+1) == true)
                {
                    if (isMine
                            (rows+1, columns+1, matrix) == false)
                        gameStart(gridMatrix, matrix, mines, rows+1, columns+1);
                }


                if (isActive (rows+1, columns-1) == true)
                {
                    if (isMine (rows+1, columns-1, matrix) == false)
                        gameStart(gridMatrix, matrix, mines, rows+1, columns-1);
                }
            }

            return (false);
        }
    }

    public void setMines(int mines[][], char matrix[][]) {
        boolean[] mark = new boolean[81];
        for (int i = 0; i < 81; i++){
            mark[i] = false;
        }
        Random rand = new Random();

        for (int i=0; i<numberofBombs; )
        {
            int random = rand.nextInt(81);
            int x = random / length;
            int y = random % length;

            if (mark[random] == false)
            {

                mines[i][0]= x;

                mines[i][1] = y;


                matrix[mines[i][0]][mines[i][1]] = '*';
                mark[random] = true;
                i++;
            }
        }

    }
    public void start(char matrix[][], char gridMatrix[][])
    {

        for (int i=0; i<length; i++)
        {
            for (int j=0; j<length; j++)
            {
                gridMatrix[i][j] = matrix[i][j] = '-';
            }
        }

    }
    public void cheatGrid (char matrix[][])
    {
        printGrid (matrix);

    }
    public void replaceMine (int rows, int columns, char m[][])
    {
        for (int i=0; i<length; i++)
        {
            for (int j=0; j<length; j++)
            {
                if (m[i][j] != '*')
                {
                    m[i][j] = '*';
                    m[rows][columns] = '-';
                    return;
                }
            }
        }
    }

    public void play ()
    {

        boolean gameOver = false;
        int over = 0;

        char[][] matrix = new char[9][9];
        char[][] gridMatrix = new char[9][9];
        Scanner scanner = new Scanner(System.in);

        int x, y;
        int[][] mines = new int [10][2];


        int currMove = 0;
        while (gameOver == false)
        {
            if(over == 0){
                start (matrix, gridMatrix);


                setMines (mines, matrix);

              //  cheatGrid(matrix);
                over = 1;
            }
            System.out.println ("\n");
            printGrid (gridMatrix);
            System.out.println("Enter your next move (row[1-9] column[1-9]):");
            x = scanner.nextInt() - 1;
            y = scanner.nextInt() - 1;
            if(!isActive(x, y)){
                System.out.println("Invalid move. Try again.");
                continue;
            }
            if(gridMatrix[x][y] != '-'){
                System.out.println("Invalid move. Try again.");
                continue;
            }

            if (currMove == 0)
            {
                if (isMine (x, y, matrix) == true)
                    replaceMine (x, y, matrix);
            }

            currMove++;

            gameOver = gameStart (gridMatrix, matrix, mines, x, y);
            if(gameOver) {
                System.out.println("Oops! You lose. Would you like to play again? (press 1 for Yes or 0 for No):");


                while(true){

                    try {
                        Scanner sc = new Scanner(System.in);
                        int yn = sc.nextInt();
                        if (yn == 1) {
                            gameOver = false;
                            over = 0;
                            break;
                        }
                        else break;
                    } catch (InputMismatchException e) {
                        System.out.print("Input is not valid \nPlease, enter 1 to restart or any number to stop\n");
                    }
                }
            }

            if ((gameOver == false) && (moves == 0)) {
                System.out.println("\nYou win.Congrats!\n");
                gameOver = true;
                System.out.println("Oops! You lose. Would you like to play again? (Y/N):");



                while (true){
                    try {
                        Scanner sc = new Scanner(System.in);
                        int yn = sc.nextInt();
                        if (yn == 1) {
                            gameOver = false;
                            over = 0;
                            break;
                        }
                        else break;
                    } catch (InputMismatchException e) {
                        System.out.println(" Input is not valid \nPlease, enter 1 to restart or any number to stop\n");
                    }
                }


            }
        }
    }
    public static void main(String[] args) {

        Main a = new Main();
        a.play();

    }

}