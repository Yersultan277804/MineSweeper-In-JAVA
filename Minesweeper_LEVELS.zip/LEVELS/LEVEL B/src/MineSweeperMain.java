public class MineSweeperMain
{
    public static void main(String[] args) {

            Grid grid = new Grid(); // LEVEL B AND C
            grid.setSizeof_grid(); // added in level D
            grid.startGame();// LEVEL B & D

    }
}
