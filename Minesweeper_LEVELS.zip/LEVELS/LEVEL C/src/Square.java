public class Square {
    private boolean open; // for open squares
    private boolean mine; // for mine
    private boolean flag; // added for a BONUS
    private int val;

    public Square () {
        open = false;
        mine = false;
        flag = false;
        val = 0;
    }

    public int getVal() {
        return val;
    }

    public void setVal(int val) {
        this.val = val;
    }

    public boolean isMine() {
        return mine;
    }

    public void setMine(boolean mine) {
        this.mine = mine;
    }

    public boolean isOpen() {
        return open;
    }

    public void setOpen(boolean open) {
        this.open = open;
    }

    public boolean isFlag() {
        return flag;
    }

    public void setFlag(boolean flag) {
        this.flag = flag;
    }

}
