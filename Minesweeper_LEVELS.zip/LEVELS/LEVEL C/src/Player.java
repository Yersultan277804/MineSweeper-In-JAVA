public class Player {
    private String name;
    private int score;

    Player(String name) {
        this.name = name;
        score = 0;
    }

    public void add(int n){

        score = score + n;
    }

    public void clear(){
        score = 0;
    }

    public int getScore(){

        return score;
    }

    public String getName(){
        return name;
    }


}
