public class PlayerHelper {
    private int turn;
    public PlayerHelper(){
        turn = 0;
    }

    public void changeT(){
        if (turn == 0)
            turn = 1;
        else
            turn = 0;
    }

    public int getTurn() {
        return turn;
    }
}
